'use client'
import { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import { useAuthUser } from '@/components/auth-provider'
import { MessageCircle, X, Loader2, Mail } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Segmented } from '@/components/ui/segmented'
import { useCenterToast } from '@/components/toast'
import { useIsMobile } from '@/lib/useMediaQuery'
import { useT } from '@/lib/i18n'

// Floating "send feedback / report a bug" widget, mounted once in
// app/(app)/layout.jsx so it's on every authed page. Deliberately sits below
// the dialog z-index ladder documented in CLAUDE.md (@modal z-[60], ui/dialog
// Overlay z-[65]/Content z-[70], centerToast z-[80]) — this widget's button
// and panel are both z-[55], so any real dialog/modal always paints over it,
// and this session's own success centerToast (fired on send) still shows on
// top of the now-closed panel.
export function FeedbackWidget() {
  const t = useT()
  const TYPES = [['feedback', t('Feedback')], ['bug', t('Bug')]]
  const pathname = usePathname()
  const { user } = useAuthUser()
  const centerToast = useCenterToast()
  const email = user?.email || null

  const [open, setOpen] = useState(false)
  const [type, setType] = useState('feedback')
  const [message, setMessage] = useState('')
  const [wantsReply, setWantsReply] = useState(true)
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const isMobile = useIsMobile()

  // Shrink/fade the FAB while the page is actively scrolling on mobile — it
  // sits over live content (balances, row actions, budget rings), so keeping
  // it at full size/opacity mid-scroll makes it more likely to obscure
  // whatever's currently passing underneath it. Settles back to full size
  // shortly after scrolling stops. Desktop (fixed bottom-right, out of the
  // content column) is unaffected.
  const [scrolling, setScrolling] = useState(false)
  useEffect(() => {
    if (!isMobile) return
    let timer
    const onScroll = () => {
      setScrolling(true)
      clearTimeout(timer)
      timer = setTimeout(() => setScrolling(false), 500)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => { window.removeEventListener('scroll', onScroll); clearTimeout(timer) }
  }, [isMobile])

  useEffect(() => {
    if (!open) return
    const onKey = (e) => { if (e.key === 'Escape') close() }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, sending])

  function close() {
    if (sending) return
    setOpen(false)
    setError('')
  }

  async function send() {
    const trimmed = message.trim()
    if (!trimmed || sending) return
    setSending(true)
    setError('')

    // Two independent, best-effort channels — fired in parallel, from the
    // browser. FormSubmit specifically must run client-side: it 403s
    // server-to-server/data-center requests (verified in Vercel logs when
    // this lived in app/api/feedback/route.js), it's designed to be POSTed
    // to directly from a page. The DB row (via /api/feedback) is the
    // durable record; FormSubmit is just the email notification. Success =
    // either one landing — only show an error if both fail.
    const dbPromise = fetch('/api/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type,
        message: trimmed,
        page: pathname,
        userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      }),
    }).then(async (res) => {
      const data = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(data?.error || t("Couldn't send that — try again"))
      return data
    })

    const emailPromise = fetch('https://formsubmit.co/ajax/info@wagewatchcompliance.com', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        _subject: `SteerMoney — new ${type}${email ? ` from ${email}` : ''}`,
        _template: 'table',
        _captcha: 'false',
        type,
        from: email || 'unknown',
        page: pathname,
        message: trimmed,
        ...(email && wantsReply ? { _replyto: email } : {}),
      }),
    }).then(async (res) => {
      const data = await res.json().catch(() => null)
      if (!res.ok || !data || data.success === 'false' || data.success === false) {
        throw new Error(`FormSubmit responded ${res.status}: ${JSON.stringify(data).slice(0, 300)}`)
      }
      return data
    })

    const [dbResult, emailResult] = await Promise.allSettled([dbPromise, emailPromise])
    const dbOk = dbResult.status === 'fulfilled'
    const emailOk = emailResult.status === 'fulfilled'
    if (!emailOk) console.error('[feedback] FormSubmit send failed:', emailResult.reason)
    if (!dbOk) console.error('[feedback] DB save failed:', dbResult.reason)

    if (dbOk || emailOk) {
      setMessage('')
      setOpen(false)
      centerToast(t('Thanks — we read every one!'))
    } else {
      setError(dbResult.reason?.message || t("Couldn't send that — try again"))
    }
    setSending(false)
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? t('Close feedback') : t('Send feedback or report a bug')}
        className={cn(
          'fixed right-3 z-[55] h-10 w-10 items-center justify-center rounded-full border border-border/60 bg-primary text-primary-foreground shadow-lg transition hover:opacity-90 sm:right-4 md:h-12 md:w-12',
          'bottom-[calc(4.75rem+env(safe-area-inset-bottom))] md:bottom-6',
          scrolling && !open ? 'scale-90 opacity-50' : 'scale-100 opacity-100',
          open ? 'hidden md:flex' : 'flex'
        )}
      >
        {open ? <X className="h-4 w-4 md:h-5 md:w-5" /> : <MessageCircle className="h-4 w-4 md:h-5 md:w-5" />}
      </button>

      {open ? (
        <>
          <div className="fixed inset-0 z-[54] md:hidden" onClick={close} />
          <div
            role="dialog"
            aria-label={t('Send feedback or report a bug')}
            className={cn(
              'fixed z-[55] border-border/60 bg-card shadow-2xl',
              'inset-x-0 bottom-0 rounded-t-2xl border-t p-4',
              'md:inset-x-auto md:bottom-24 md:right-4 md:w-80 md:rounded-2xl md:border'
            )}
            style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom))' }}
          >
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-[0.9375rem] font-extrabold tracking-tight">{t('Send us feedback')}</h3>
              <button type="button" onClick={close} className="text-muted-foreground hover:text-foreground md:hidden">
                <X className="h-4 w-4" />
              </button>
            </div>

            <Segmented options={TYPES} value={type} onChange={setType} className="mb-3" />

            <textarea
              autoFocus
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={
                type === 'bug'
                  ? t("What happened? The more detail, the faster we can fix it.")
                  : t("What's on your mind? We read every note.")
              }
              className="w-full resize-none rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring [color-scheme:dark]"
            />
            <p className="mt-1.5 text-[0.6875rem] text-muted-foreground">
              {t('No need for a screenshot — just describe it in your own words.')}
            </p>

            {email ? (
              <label className="mt-2.5 flex items-start gap-2 text-[0.75rem] text-muted-foreground">
                <input
                  type="checkbox"
                  checked={wantsReply}
                  onChange={(e) => setWantsReply(e.target.checked)}
                  className="mt-0.5 h-3.5 w-3.5 shrink-0 accent-primary"
                />
                <span className="flex min-w-0 items-start gap-1">
                  <Mail className="mt-0.5 h-3 w-3 shrink-0" />
                  {t('Email me back at')} <span className="font-semibold text-foreground">{email}</span> {t('if needed')}
                </span>
              </label>
            ) : null}

            {error ? <p className="mt-2 text-[0.75rem] font-semibold text-red-400">{error}</p> : null}

            <Button className="mt-3 w-full" disabled={!message.trim() || sending} onClick={send}>
              {sending ? <Loader2 className="animate-spin" /> : null}
              {sending ? t('Sending…') : t('Send')}
            </Button>
          </div>
        </>
      ) : null}
    </>
  )
}
